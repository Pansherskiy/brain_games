### Hexlet tests and linter status:
[![Actions Status](https://github.com/Pansherskiy/brain_games/workflows/hexlet-check/badge.svg)](https://github.com/Pansherskiy/brain_games/actions)

brain-even
https://asciinema.org/a/558495

brain-calc
https://asciinema.org/a/558769

brain-gcd
https://asciinema.org/a/558817

brain-progression
https://asciinema.org/a/558864

brain-prime
https://asciinema.org/a/558924
