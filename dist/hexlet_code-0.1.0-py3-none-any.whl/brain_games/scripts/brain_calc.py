#!/usr/bin/env python3
from ..games.calc import run_game


def main():
    run_game()


if __name__ == "__main__":
    main()
